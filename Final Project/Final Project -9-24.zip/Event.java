// Filename: Event.java
// Written by Sandi Cook
// Written on September 13, 2023

public class Event {

  // Public final static fields.
  public static final double LOWER_PRICE_PER_GUEST = 32.0; // Lower price per guest
  public static final double HIGHER_PRICE_PER_GUEST = 35.0; // Higher price per guest
  public static final int CUTOFF_VALUE = 50;

  // Private fields.
  private String eventNumber;
  private int numberOfGuests;
  private double price;
  private String phoneNumber; // New field for contact phone number.

  // Public set methods.
  public void setEventNumber(String eventNumber) {
    // Check if the eventNumber matches the required format.
    if (eventNumber.matches("^[A-Z]\\d{3}$")) {
      this.eventNumber = eventNumber;
    } else {
      this.eventNumber = "A000"; // Default value if format is invalid.
    }
  }

  // Set the contact phone number.
  public void setPhoneNumber(String phoneNumber) {
    // Remove all non-digit characters from the input and ensure it's exactly 10 digits.
    phoneNumber = phoneNumber.replaceAll("[^0-9]", "");
    if (phoneNumber.length() == 10) {
      this.phoneNumber = "(" + phoneNumber.substring(0, 3) + ") " +
                        phoneNumber.substring(3, 6) + "-" +
                        phoneNumber.substring(6);
    } else {
      this.phoneNumber = "(000) 000-0000"; // Default value if not 10 digits.
    }
  }

  // New method to check if the event is large.
  public boolean isLargeEvent() {
    return numberOfGuests >= CUTOFF_VALUE;
  }

  // Modified method to set the number of guests and calculate the price.
  public void setGuests(int numberOfGuests) {
    this.numberOfGuests = numberOfGuests;

    if (numberOfGuests >= CUTOFF_VALUE) {
      this.price = numberOfGuests * LOWER_PRICE_PER_GUEST; // Use lower price for large events
    } else {
      this.price = numberOfGuests * HIGHER_PRICE_PER_GUEST; // Use higher price for small events
    }
  }

  // Public get methods.
  public String getEventNumber() {
    return this.eventNumber;
  }

  public int getNumberOfGuests() {
    return this.numberOfGuests;
  }

  public double getPrice() {
    return this.price;
  }

  // Get the formatted contact phone number.
  public String getPhoneNumber() {
    return this.phoneNumber;
  }

  // Constructors.
  // Parameterized constructor with event number, number of guests, and phone number.
  public Event(String eventNumber, int numberOfGuests, String phoneNumber) {
    this.setEventNumber(eventNumber);
    this.setGuests(numberOfGuests);
    this.setPhoneNumber(phoneNumber);
  }

  // Default constructor initializes with default values.
  public Event() {
    this("A000", 0, "(000) 000-0000");
  }
}
