import java.util.Scanner;

public class EventDemo {
    public static void main(String[] args) {
        // Create three Event objects.
        Event event1 = new Event();
        Event event2 = new Event();
        Event event3 = new Event();

        // Create a scanner for user input.
        Scanner scanner = new Scanner(System.in);

        // Prompt the user for event details for each Event.
        setEventDetails(event1, scanner, 1);
        setEventDetails(event2, scanner, 2);
        setEventDetails(event3, scanner, 3);

        // Display the details for each Event object.
        System.out.println("Event 1 Details:");
        displayEventDetails(event1);

        System.out.println("Event 2 Details:");
        displayEventDetails(event2);

        System.out.println("Event 3 Details:");
        displayEventDetails(event3);

        // Find the Event object with the fewest number of guests.
        Event smallestEvent = findSmallestEvent(event1, event2, event3);

        // Display "Please come to my event!" for each guest.
        System.out.println("Please come to my event!");
        for (int i = 0; i < smallestEvent.getNumberOfGuests(); i++) {
            System.out.println("Please come to my event!");
        }
    }

    // This method sets the event number, number of guests, and contact phone number for an Event object, ensuring valid values.
    public static void setEventDetails(Event event, Scanner scanner, int eventNumber) {
        String eventNum;
        int numberOfGuests;
        String phoneNumber;

        do {
            System.out.print("Enter the event number for Event " + eventNumber + ": ");
            eventNum = scanner.next();
            System.out.print("Enter the number of guests for Event " + eventNumber + ": ");
            numberOfGuests = scanner.nextInt();
            System.out.print("Enter the contact phone number for Event " + eventNumber + ": ");
            phoneNumber = scanner.next();

            if (numberOfGuests < 5 || numberOfGuests > 100) {
                System.out.println("Number of guests must be between 5 and 100 inclusive. Please try again.");
            }

            if (!eventNum.matches("^[A-Z]\\d{3}$")) {
                System.out.println("Event number must start with an uppercase letter followed by three digits. Please try again.");
            }
        } while (numberOfGuests < 5 || numberOfGuests > 100 || !eventNum.matches("^[A-Z]\\d{3}$"));

        event.setEventNumber(eventNum);
        event.setGuests(numberOfGuests);
        event.setPhoneNumber(phoneNumber);
    }

    // This method displays the details of an Event object.
    public static void displayEventDetails(Event event) {
        System.out.println("Event number: " + event.getEventNumber());
        System.out.println("Number of guests: " + event.getNumberOfGuests());
        System.out.println("Price per guest: $" + event.getPrice());
        System.out.println("Contact phone number: " + event.getPhoneNumber());
        System.out.println();
    }

    // This method finds the Event object with the fewest number of guests among three events.
    public static Event findSmallestEvent(Event event1, Event event2, Event event3) {
        int smallestGuests = Math.min(event1.getNumberOfGuests(), Math.min(event2.getNumberOfGuests(), event3.getNumberOfGuests()));

        if (smallestGuests == event1.getNumberOfGuests()) {
            return event1;
        } else if (smallestGuests == event2.getNumberOfGuests()) {
            return event2;
        } else {
            return event3;
        }
    }
}
