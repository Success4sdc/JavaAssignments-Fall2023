// Filename: EventDemo.java
// Written by Sandi Cook
// Written on September 3, 2023

/*
* Purpose: 
*/
import java.util.Scanner;

public class EventDemo {

  public static void main(String[] args) {
    // Create a default Event object.
    Event event1 = new Event();

    // Create an Event object from values input by the user.
    Scanner scanner = new Scanner(System.in);

    System.out.print("Enter the event number: ");
    String eventNumber = scanner.nextLine();

    System.out.print("Enter the number of guests: ");
    int numberOfGuests = scanner.nextInt();

    Event event2 = new Event(eventNumber, numberOfGuests);

    // Display the details of each event.
    displayDetails(event1);
    displayDetails(event2);
  }

  // This method displays the details of an Event object.
  public static void displayDetails(Event event) {
    System.out.println("Event number: " + event.getEventNumber());
    System.out.println("Number of guests: " + event.getNumberOfGuests());
    System.out.println("Price: $" + event.getPrice());
  }
}
