// Filename: YummyMotto.java
// Written by Sandi Cook
// Written on September 3, 2023

/*
* Purpose: 
*/
public class YummyMotto2 {

  public static void main(String[] args) {
    String motto = "Yummy makes the food that makes it a party";
    int length = motto.length();

    // Print the top border.
    System.out.println("******************************************");

    // Print the motto.
    System.out.println(motto);

    // Print the bottom border.
    System.out.println("******************************************");
  }

}
