// Color.java
// Written by Sandra Cook
// Written on: September 15, 2023

// Enumeration representing colors
public enum Color {
    BLACK, BLUE, GREEN, RED, WHITE, YELLOW
}
