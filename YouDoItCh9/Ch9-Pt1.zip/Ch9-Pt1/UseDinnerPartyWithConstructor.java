// Filename: UseDinnerPartyWithConstructor.java
// Written by Sandi Cook
// Written on September 19, 2023

/*
 * Purpose: Define the UseDinnerPartyWithConstructor class
 * Description: This class contains the main method to demonstrate the use of the DinnerPartyWithConstructor class by creating a DinnerPartyWithConstructor object.
 */
public class UseDinnerPartyWithConstructor {
    public static void main(String[] args) {
        DinnerPartyWithConstructor aDinnerParty = new DinnerPartyWithConstructor();
    }
}
