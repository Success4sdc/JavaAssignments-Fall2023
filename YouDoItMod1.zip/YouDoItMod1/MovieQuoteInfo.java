//Filename MovieQuoteInfo.java
//Written By Sandi Cook
//Written August 22, 2023
public class MovieQuoteInfo {

    public static void main(String[] args) {
        
        // Movie 1
        System.out.println("Quote: \"May the Force be with you.\"");
        System.out.println("Movie: Star Wars");
        System.out.println("Character: Multiple characters");
        System.out.println("Year: 1977");
        System.out.println();

        // Movie 2
        System.out.println("Quote: \"Here's looking at you, kid.\"");
        System.out.println("Movie: Casablanca");
        System.out.println("Character: Rick Blaine");
        System.out.println("Year: 1942");
        System.out.println();

        // Movie 3
        System.out.println("Quote: \"Life is like a box of chocolates. You never know what you're gonna get.\"");
        System.out.println("Movie: Forrest Gump");
        System.out.println("Character: Forrest Gump");
        System.out.println("Year: 1994");
        System.out.println();

        // Movie 4
        System.out.println("Quote: \"I'll be back.\"");
        System.out.println("Movie: The Terminator");
        System.out.println("Character: The Terminator");
        System.out.println("Year: 1984");
    }
}
