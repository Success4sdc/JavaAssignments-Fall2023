//Filename First Dialogue.java
//Written By Sandi Cook
//Written August 22, 2023
import javax.swing.JOptionPane;

public class FirstDialogue 
{
    
    public static void main(String[] args)
    {
        JOptionPane.showMessageDialog(null, "Hello World!!");
    }

    
}
