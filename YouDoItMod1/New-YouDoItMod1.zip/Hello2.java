//Filename Hello2.java
//Written by Sandi Cook
//Written on August 21, 2023
//
//
//
public class Hello2 {
/* This class demonstrates the use of the println()
  method to print the message Hello World
 */
   public static void main(String[] args) {
    System.out.println("Hello, world");
   }
}
