//Filename CharDemo.java
//Written by Sandi Cook
//Written on August 24, 2023
//
//
//
public class CharDemo {

	public static void main(String[] args) {
        char initial = 'A';


		System.out.println(initial);
        System.out.print(("\t\"abc\\def\bghi\n\njkl"));	}

}