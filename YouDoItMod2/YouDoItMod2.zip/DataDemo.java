//Filename DataDemo.java
//Written by Sandi Cook
//Written on August 21, 2023


public class DataDemo {
    public static void main(String[] args)
    {
        int aWholeNumber = 315;
        System.out.print("The number is "); 
        System.out.println(aWholeNumber);

    }
    
}
